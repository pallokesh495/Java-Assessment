public class NumberFormatException {
    public static void main(String[] args) {
        String invalidNumber = "abc";
        int number = Integer.parseInt(invalidNumber);  
    }
}
