public class ArithmeticException {
    public static void main(String[] args) {
        int result = 10 / 0; // This will throw ArithmeticException (divide by zero)
        System.out.println(result);
    }
}
