public class GenerateArithmeticException {
    public static void main(String[] args) {
        int result = 10 / 0;  // Generates ArithmeticException
    }
}
