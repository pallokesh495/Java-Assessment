import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class FileNotFoundException {
    public static void main(String[] args) throws FileNotFoundException {
        File file = new File("nonexistentfile.txt");
        FileReader fr = new FileReader(file);  // Generates FileNotFoundException
    }
}
