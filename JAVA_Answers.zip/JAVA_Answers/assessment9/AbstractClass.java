abstract class AbstractClass {
    void nonAbstractMethod() {
        System.out.println("This is a non-abstract method.");
    }

    abstract void abstractMethod();
}
