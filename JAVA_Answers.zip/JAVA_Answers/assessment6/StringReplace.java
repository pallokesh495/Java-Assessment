public class StringReplace {
    public static void main(String[] args) {
        String str = "Hello World";
        String newStr = str.replace('o', 'a');
        System.out.println(newStr);
    }
}
