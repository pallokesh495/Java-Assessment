public class StringCaseConversion {
    public static void main(String[] args) {
        String str = "Hello World";
        String upperCaseStr = str.toUpperCase();
        String lowerCaseStr = str.toLowerCase();

        System.out.println("Uppercase: " + upperCaseStr);
        System.out.println("Lowercase: " + lowerCaseStr);
    }
}
