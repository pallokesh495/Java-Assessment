public class StringSubstring {
    public static void main(String[] args) {
        String str = "Hello World";
        String subStr = str.substring(6); // Extract from index 6 to the end
        System.out.println(subStr);
    }
}
