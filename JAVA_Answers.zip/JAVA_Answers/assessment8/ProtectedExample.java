package package1;

public class ProtectedExample {
    protected int protectedField = 30;
    
    protected void protectedMethod() {
        System.out.println("Protected method");
    }
}
