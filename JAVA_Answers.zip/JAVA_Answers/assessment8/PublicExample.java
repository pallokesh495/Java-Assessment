package package1;

public class PublicExample {
    public int publicField = 40;
    
    public void publicMethod() {
        System.out.println("Public method");
    }
}
