package package2;

import package1.ProtectedExample;

public class TestProtectedAccess {
    public static void main(String[] args) {
        ProtectedExample example = new ProtectedExample();
        
    }
}
