package p1;

class DefaultExample {
    int defaultField = 20;
    
    void defaultMethod() {
        System.out.println("Default method");
    }
}
