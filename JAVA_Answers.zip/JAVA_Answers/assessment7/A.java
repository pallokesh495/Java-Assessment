public class A {
    public void methodA1() {
        System.out.println("Method A1");
    }

    public void methodA2() {
        System.out.println("Method A2");
    }

    public void methodOverride() {
        System.out.println("Method Override in A");
    }
}
