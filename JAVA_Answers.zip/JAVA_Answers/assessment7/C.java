public class C extends B {
    public void methodC1() {
        System.out.println("Method C1");
    }

    public void methodC2() {
        System.out.println("Method C2");
    }

    @Override
    public void methodOverride() {
        System.out.println("Method Override in C");
    }
}
