public class B extends A {
    public void methodB1() {
        System.out.println("Method B1");
    }

    public void methodB2() {
        System.out.println("Method B2");
    }

    @Override
    public void methodOverride() {
        System.out.println("Method Override in B");
    }
}
