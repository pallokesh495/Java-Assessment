public class PrintName {
    public static void main(String[] args) {
        System.out.println("Your Name");
    }
}
