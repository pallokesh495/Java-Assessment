public class DataTypes {
    public static void main(String[] args) {
        int intVar = 10;
        boolean boolVar = true;
        char charVar = 'A';
        float floatVar = 5.75f;
        double doubleVar = 19.99;

        System.out.println(intVar);
        System.out.println(boolVar);
        System.out.println(charVar);
        System.out.println(floatVar);
        System.out.println(doubleVar);
    }
}
