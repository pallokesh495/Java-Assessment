/**
 * This class demonstrates the use of documentation comments.
 */
public class DocumentationComment{

    /**
     * This method prints a message to the console.
     * @param args Command-line arguments
     */
    public static void main(String[] args) {
        System.out.println("This is a documentation comment example");
    }
}
