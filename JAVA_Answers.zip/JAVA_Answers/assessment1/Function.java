public class Function {
    public static void main(String[] args) {
        printName();
    }

    public static void printName() {
        System.out.println("Your Name");
    }
}
