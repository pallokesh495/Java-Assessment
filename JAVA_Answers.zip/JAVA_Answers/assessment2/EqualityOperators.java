public class EqualityOperators {
    public static void main(String[] args) {
        int a = 10, b = 5, c = 10;
        
        System.out.println("a == b: " + (a == b));
        System.out.println("a == c: " + (a == c));
        System.out.println("a != b: " + (a != b));
        System.out.println("a != c: " + (a != c));
    }
}
