public class IncrementDecrementOperators {
    public static void main(String[] args) {
        int num = 10;
        
        System.out.println("Original: " + num);
        num++;  // Increment
        System.out.println("After Increment: " + num);
        num--;  // Decrement
        System.out.println("After Decrement: " + num);
    }
}
