public class CompareNumbers {
    public static void main(String[] args) {
        int num1 = 30, num2 = 20;

        if (num1 > num2) {
            System.out.println("Larger number: " + num1);
            System.out.println("Smaller number: " + num2);
        } else {
            System.out.println("Larger number: " + num2);
            System.out.println("Smaller number: " + num1);
        }
    }
}
