public class EqualNumbers {
    public static void main(String[] args) {
        int num1 = 15, num2 = 20;
        
        if (num1 == num2) {
            System.out.println("Both numbers are equal");
        } else {
            System.out.println("Numbers are not equal");
        }
    }
}
