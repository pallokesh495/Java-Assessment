class DefaultClass implements DefaultMethodInterface {

          // No implementation needed for defaultMethod
}

public class Main4 {
    public static void main(String[] args) {
        DefaultClass obj = new DefaultClass();
        obj.defaultMethod();
    }
}
