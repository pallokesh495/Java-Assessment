interface StaticFinalInterface {
    static final int CONSTANT = 42;
    
    void method();
}
