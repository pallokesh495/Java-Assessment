public interface PublicInterface {
    int FIELD = 100;
    
    void publicMethod();
}
