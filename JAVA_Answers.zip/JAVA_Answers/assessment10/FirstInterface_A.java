interface FirstInterface_A {
    void commonMethod();
}

interface SecondInterface_A {
    void commonMethod();
}
