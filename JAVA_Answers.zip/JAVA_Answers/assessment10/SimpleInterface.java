interface SimpleInterface {
    void singleMethod();
}
