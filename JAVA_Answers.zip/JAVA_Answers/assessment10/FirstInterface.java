interface FirstInterface {
    void methodOne();
}

interface SecondInterface {
    void methodTwo();
}
